package com.Car_Rental_Spring.enums;

public enum RentalStatus {

    CREATED,
    APPROVED,
    REJECTED,

    COMPLETED,

    CANCELED,
}
